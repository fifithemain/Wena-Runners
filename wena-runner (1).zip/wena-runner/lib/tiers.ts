// The shopper fee: what a Runner earns for finding + buying the item.
// This is separate from the courier fee, since a different WENA courier
// leg handles the actual drop-off to the customer.
export const TIERS = {
  small: { label: "1 to 5 items", fee: 130, runnerCut: 70 },
  medium: { label: "6 to 10 items", fee: 180, runnerCut: 90 },
  heavy: { label: "Heavy / bulky items", fee: 220, runnerCut: 110 },
} as const;

export type TierKey = keyof typeof TIERS;

// Flat WENA courier fee for the delivery leg (Runner -> customer address).
// Not charged when the customer chooses store pickup instead.
// Change this via the NEXT_PUBLIC_COURIER_FEE env var (needs a redeploy to take effect).
export const COURIER_FEE = Number(process.env.NEXT_PUBLIC_COURIER_FEE || 60);

export type FulfillmentType = "delivery" | "pickup";

// Front-of-list partner stores. Add or rename here; "Other" is always offered too.
export const PARTNER_STORES = [
  { name: "Peoples Market", url: "https://www.facebook.com/profile.php?id=61576835366849" },
  { name: "Yaya Trading", url: "https://www.facebook.com/profile.php?id=61557407364279" },
  { name: "Payless Trading", url: "https://www.facebook.com/profile.php?id=61588453663462" },
];

export const STORE_PRESETS = [...PARTNER_STORES.map((s) => s.name), "Other"];
