import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase";

// Public, privacy-safe view of the board for the home page:
// store name and Runner fee only. No customer details.
export const dynamic = "force-dynamic";

export async function GET() {
  const supabase = supabaseAdmin();
  const { data, error } = await supabase
    .from("jobs")
    .select("store_name, shopper_fee")
    .eq("status", "open")
    .order("created_at", { ascending: false })
    .limit(3);
  if (error) {
    return NextResponse.json({ jobs: [] });
  }
  return NextResponse.json({ jobs: data || [] });
}
